export function Chapter01Slide() {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-blue-600 via-blue-700 to-purple-700 text-white px-16 pb-12">
      <div className="text-center space-y-8 animate-in fade-in duration-1000">
        <div className="text-8xl font-bold tracking-tight">
          CHAPTER 01
        </div>
        <div className="h-1 w-32 bg-white/80 mx-auto" />
        <div className="text-4xl font-semibold tracking-wide">
          프롤로그
        </div>
        <div className="text-2xl text-blue-100 mt-8">
          IP 관리 현황 및 문제점
        </div>
      </div>
    </div>
  )
}
